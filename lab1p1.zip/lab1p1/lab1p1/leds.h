/* 
* File:   leds.h
* Author: Garrett Vanhoy
*
* Created on December 27, 2014, 1:31 PM
*/

#ifndef LEDS_H
#define	LEDS_H

void initLEDs();
void stopLED();
void runLED();
void toggleLED();

#endif	/* LEDS_H */

