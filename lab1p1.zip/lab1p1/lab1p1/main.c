// ******************************************************************************************* //
//
// File:         lab1p1.c
// Date:         12-30-2014
// Authors:      Garrett Vanhoy
//
// Description: This is the solution for part 1 of Lab 1. Just blinking LEDs with an external switch.
// This switch must be debounced.
// ******************************************************************************************* //

#include <xc.h>
#include <sys/attribs.h>
#include "switch.h"
#include "timer.h"
#include "leds.h"
#include "interrupt.h"
#include "config.h"

// ******************************************************************************************* //
#define DEBOUNCE_DELAY_MS 1

typedef enum stateTypeEnum{
    debouncePress, debounceRelease, waitForPress, waitForRelease
} stateType;

volatile stateType state = waitForPress;
volatile int switchPressedFlag = 0;

int main(void)
{
    SYSTEMConfigPerformance(10000000);
    
    initLEDs();
    initSwitch2();
    enableInterrupts();
    
    while(1)
    {
        
    }
    
    return 0;
}

void __ISR(_CHANGE_NOTICE_VECTOR, IPL7SRS) _CNInterrupt( void ){
    switchPressedFlag = PORTAbits.RA7;
    IFS1bits.CNAIF = 0;
    if (state == waitForPress) state = debouncePress;
    else if(state == waitForRelease) state = debounceRelease;
}