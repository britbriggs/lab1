/* 
 * File:   switch.c
 * Author: gvanhoy
 *
 * Created on August 27, 2015, 3:12 PM
 */

#include <xc.h>
#include <sys/attribs.h>
#include "switch.h"

#define INPUT 1
#define OUTPUT 0

#define ENABLED 1 
#define DISABLED 0

void initSwitch2(){
    TRIS_SW2 = INPUT;           // Configure switch as input
    CNCONAbits.ON = 1;          // Enable overall interrupt
    CNIE_SW2 = ENABLED;         // Enable pin CN
 //   CNPU_SW2 = ENABLED;         // Enable pull-up resistor
    IFS1bits.CNAIF = 0;         // Put down the flag
    IPC8bits.CNIP = 7;          // Configure interrupt priority
    IEC1bits.CNAIE = ENABLED;   // Enable interrupt for A pins
}