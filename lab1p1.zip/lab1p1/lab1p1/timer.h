/* 
 * File:   initTimer.h
 * Author: gvanhoy
 *
 * Created on December 30, 2014, 8:07 PM
 */

#ifndef INITTIMER_H
#define	INITTIMER_H

void initTimer2();
void delayMs(unsigned int delay);

#endif	/* INITTIMER_H */

