// ******************************************************************************************* //
//
// File:         lab1p2.c
// Date:         12-30-2014
// Authors:      Garrett Vanhoy
//
// Description: 
// ******************************************************************************************* //

#include <xc.h>
#include <sys/attribs.h>
#include "lcd.h"
#include "timer.h"
#include "leds.h"
#include "switch.h"
#include "config.h"
#include "interrupt.h"


// ******************************************************************************************* //
#define DEBOUNCE_DELAY_MS 1

typedef enum stateTypeEnum{
    debouncePress, debounceRelease, waitForPress, waitForRelease
} stateType;

volatile stateType state = waitForPress;
volatile int switchPressedFlag = 0;
volatile long int counter=0;
volatile int resetFlag=0;

int main(void)
{
    SYSTEMConfigPerformance(10000000);
    
    initLEDs();                 // Initialize LED
    initLCD();                  // Initialize LCD
    initSwitch1();              // Initialize 1st Switch
    initSwitch2();              // Initialize 2nd Switch
    initTimer1();
    
    enableInterrupts();
    char time[]="00:00:00";                 //Char* used for overall time
     moveCursorLCD(5,0);                //Initiliazation LCD position
     printStringLCD("Stopped");         // Init LCD string
    
    while(1)
    {
        switch(state){
            
            case debouncePress:             //Debouncing the Press
                delayUs(500);             // 50000us delay
                state=waitForRelease;       //Change states to wait for Release
                if(T1CONbits.ON==1){        // If T1 is on turn off and update LCD with correct "Stopped" message
                    stopTimer1();
                    moveCursorLCD(5,0);
                    printStringLCD("Stopped");
                    moveCursorLCD(3,1);
                }
                else{               //Otherwise if T1 is off, turn on. and update LCD
                    startTimer1();
                    moveCursorLCD(5,0);
                    printStringLCD("Started");
                    moveCursorLCD(5,1);
                }
                
                if(LATGbits.LATG12==1){     //If LED Run is on then Stop
                   turnOnLED(2); 
                }
                else{
                   turnOnLED(1);        //Else LED STOP is on then RUN
                }
                
                break;
            case debounceRelease:
                delayUs(500);       //Delay for debounce
                state=waitForPress;     //Wait for press
                break;
        }
        getTimeString(counter, time);       //Time string
        moveCursorLCD(4,2);             //Move cursor to correct position
        printStringLCD(time);           //Write to LCD
        if(T1CONbits.ON==0 && PORTDbits.RD6==0){        //If reset is pressed and Timer is paused then reset
            counter=0;                      
            state=waitForPress;
            clearLCD();
             moveCursorLCD(5,0);
             printStringLCD("Stopped");
             moveCursorLCD(3,1);
        }
        
    }
    
    return 0;
}
void __ISR(_TIMER_1_VECTOR, IPL7SRS) _T1Interupt() {
    
    IFS0bits.T1IF = 0;
    counter=counter+1;          //Increment timer
    
}

void __ISR(_CHANGE_NOTICE_VECTOR, IPL7SRS) _CNInterrupt( void ){
    switchPressedFlag = PORTAbits.RA7;  
    IFS1bits.CNAIF = 0;
    
           if (state == waitForPress) state = debouncePress;            //Same state machine as p1
           else if(state == waitForRelease) state = debounceRelease; 
    
   // else{
      
  //  }

}

