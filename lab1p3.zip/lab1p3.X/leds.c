/*
* File:   leds.c
* Author: 
*
* Created on December 27, 2014, 1:31 PM
*/
#include <xc.h>

#define OUTPUT 0
#define RUN 1
#define STOP 2


//two LEDS TRD1 (RG12) RUN, TRD2 (RG14) STOP)

void initLEDs(){
    
    TRISGbits.TRISG12=OUTPUT;
    TRISGbits.TRISG14=OUTPUT;
    
    
    
    ODCGbits.ODCG12=1;  //EN ODC Mode TRD1
    ODCGbits.ODCG14=1;  //EN ODC Mode TRD2
    
    LATGbits.LATG12=1;
    LATGbits.LATG14=0;
    
    
}

void turnOnLED(int led){
    
    
    switch(led)
    {
        case RUN:
            
            LATGbits.LATG12=1;
            LATGbits.LATG14=0;
            break;
        case STOP:
            
            LATGbits.LATG12=0;
            LATGbits.LATG14=1;
            break;
    }
    
}