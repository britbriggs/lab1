/* 
 * File:   timer.h
 * Author: 
 *
 * Created on December 30, 2014, 8:07 PM
 */

#ifndef INITTIMER_H
#define	INITTIMER_H
void initTimer1();
void delayMs(unsigned int delay);
char* getTimeString(long int counter, char* time);
#endif	/* INITTIMER_H */

